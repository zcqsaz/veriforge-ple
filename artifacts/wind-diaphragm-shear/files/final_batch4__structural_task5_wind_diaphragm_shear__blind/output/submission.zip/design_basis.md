# Design basis

This starter package preserves the required file and worksheet structure for a reproducible harness artifact.
